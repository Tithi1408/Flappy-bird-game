# flappy-bird
This game is made using python.
TEAM MEMBERS
<br>
1.)<a href="https://github.com/Abhiman1211">Abhiman Gautam </a>
<br>
2.)<a href="https://github.com/Riya1929">Riya Gandhi </a>
<br>
3.)<a href="https://github.com/zankhana46">Zankhana Mehta </a>
